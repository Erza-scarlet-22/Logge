# ──────────────────────────────────────────────────────────────────────────────
# lambda/lambda_handler.py  –  Log processing Lambda function
#
# Triggered by: S3 event when a new log file lands in the raw-logs bucket.
#
# What it does:
#   1. Downloads the raw log file from S3
#   2. Parses it using the existing log_parser.py module
#   3. Converts to CSV rows using log_to_csv_service.py
#   4. Writes the processed CSV back to S3 (processed/ prefix)
#   5. Optionally emits structured log events to CloudWatch
#
# Environment variables:
#   PROCESSED_BUCKET  – S3 bucket for processed CSV output
#                       (defaults to same bucket with processed/ prefix)
#   LOG_LEVEL         – Logging verbosity (default: INFO)
# ──────────────────────────────────────────────────────────────────────────────

import json
import logging
import os
import tempfile
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

# Modules from Conversion/ (co-packaged in the Lambda ZIP)
from log_parser import parse_log_line           # type: ignore
from log_to_csv_service import (                # type: ignore
    convert_log_to_rows,
    write_rows_to_csv,
    write_unique_errors_json,
)

# ── Logging setup ─────────────────────────────────────────────────────────────
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
)
logger = logging.getLogger("log-processor")

# ── AWS clients (initialised once per Lambda container) ──────────────────────
s3 = boto3.client("s3")
cloudwatch = boto3.client("logs")

# ── Configuration ─────────────────────────────────────────────────────────────
PROCESSED_BUCKET = os.environ.get("PROCESSED_BUCKET", "")  # Falls back to source bucket


def handler(event, context):
    """
    Lambda entry point.

    Event format (S3 trigger):
    {
        "Records": [
            {
                "s3": {
                    "bucket": {"name": "my-raw-logs-bucket"},
                    "object": {"key": "incoming/app-2024-01-15.log"}
                }
            }
        ]
    }
    """
    logger.info("Log processor Lambda invoked. RequestId: %s", context.aws_request_id)
    results = []

    for record in event.get("Records", []):
        bucket = record["s3"]["bucket"]["name"]
        key    = record["s3"]["object"]["key"]
        logger.info("Processing s3://%s/%s", bucket, key)

        try:
            result = _process_log_file(bucket, key, context)
            results.append({"key": key, "status": "success", **result})
        except Exception as exc:
            logger.error("Failed to process %s: %s", key, exc, exc_info=True)
            results.append({"key": key, "status": "error", "error": str(exc)})

    logger.info("Processing complete. Results: %s", json.dumps(results))
    return {"statusCode": 200, "body": json.dumps(results)}


def _process_log_file(bucket: str, key: str, context) -> dict:
    """Download, parse, and re-upload a single log file."""
    output_bucket = PROCESSED_BUCKET or bucket
    stem = Path(key).stem  # e.g. "app-2024-01-15"

    with tempfile.TemporaryDirectory() as tmpdir:
        # ── 1. Download raw log ───────────────────────────────────────────
        local_log = os.path.join(tmpdir, "input.log")
        logger.debug("Downloading s3://%s/%s to %s", bucket, key, local_log)
        s3.download_file(bucket, key, local_log)

        # ── 2. Parse and convert ──────────────────────────────────────────
        rows, unique_errors = convert_log_to_rows(local_log)
        logger.info("Parsed %d log rows, %d unique errors", len(rows), len(unique_errors))

        # ── 3. Write CSV and error JSON to temp files ─────────────────────
        csv_path   = os.path.join(tmpdir, f"{stem}.csv")
        errors_path = os.path.join(tmpdir, f"{stem}-errors.json")
        write_rows_to_csv(rows, csv_path)
        write_unique_errors_json(unique_errors, errors_path)

        # ── 4. Upload processed files to S3 ──────────────────────────────
        csv_s3_key    = f"processed/{stem}.csv"
        errors_s3_key = f"processed/{stem}-errors.json"

        s3.upload_file(csv_path,    output_bucket, csv_s3_key)
        s3.upload_file(errors_path, output_bucket, errors_s3_key)
        logger.info("Uploaded processed files to s3://%s/processed/", output_bucket)

        return {
            "rows":          len(rows),
            "unique_errors": len(unique_errors),
            "csv_key":       csv_s3_key,
            "errors_key":    errors_s3_key,
        }
